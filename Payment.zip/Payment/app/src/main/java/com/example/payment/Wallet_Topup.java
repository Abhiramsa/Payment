package com.example.payment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Wallet_Topup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet__topup);
    }
}