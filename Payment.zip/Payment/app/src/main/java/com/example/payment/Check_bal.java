package com.example.payment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Check_bal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_bal);
    }
}